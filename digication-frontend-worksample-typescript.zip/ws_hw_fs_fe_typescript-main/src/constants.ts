export const CONTAINER_WIDTH = 1024;
export const NUM_COLUMNS = 12;
export const GUTTER_SIZE = 10;
export const COLUMN_WIDTH = (CONTAINER_WIDTH - GUTTER_SIZE) / NUM_COLUMNS;
